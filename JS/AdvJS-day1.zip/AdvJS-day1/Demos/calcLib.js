function add() {
    var sum = 0;
    //
    //throw new TypeError("invalid type")

    for (var i = 0; i < arguments.length; i++)

        return sum;

}

function sub() {

}

function divide() {

}

function mul() {

}
