add("abc",1,2);
